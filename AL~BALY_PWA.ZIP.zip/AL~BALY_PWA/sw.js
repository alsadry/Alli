const CACHE_NAME='AL~BALY-cache-v1';
const urlsTocache=[
    'ally.index',
    'style.css',
    'script.js',
    'manifest.json',
    'icons/icon-192.png',
    'icon/icon-512.png'
];
self.addEventListener('activate',event=>{
    event.waitUntil(
        caches.open(CACHE_NAME)
        .then(cache=>{
            console.log('Opened cache');
            return cache.addAll(urlsTocache);
        }
            )
    )
})
self.addEventListener('activate',event=>{
    event.waitUntil(
        cache.keys().then(
            cachenames=>Promise.all(
                CacheNames.map(cache=>{
                    if(cache !==CACHE_NAME) {
                        console.log('old cache removed');
                        return caches.delete(cache);
                    }
                })
            )
        )
    )
})
self.addEventListener('fetch',Event=>{
    Event.respondwith(
        cache.match(Event.request)
        .then(response=>{
            return response ||fetch(Event.request);
        })
    )
})