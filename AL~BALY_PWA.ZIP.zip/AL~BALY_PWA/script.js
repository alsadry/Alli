function login() {
    const username = document.getElementById('username').Value.trim();
    const password = document.getElementById('password').Value.trim();
    if (username && password) {
        localStorage.setItem('username', username);
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('app-section').style.display = 'block';
        document.getElementById('username').textContent = username;
    } else {
        alert('tafadhali jaza jina la mtumiaji na nenosiri.');
    }
}
function addproduct() {
    const name = document.getElementById('productnsme').Value.trim();
    const price = document.getElementById('productprice').value.trim();
    const desc = document.getElementById('productdesc').value.trim();
    if (!name || !price || !desc) {
        alert("tafadhali jaza kila sehemu!");
        return;
    }
    const productlist = document.getElementById('productlist');
    const card = document.createElement('div');
    card.innerHTML
    productlist.appendChild(card);
    document.getElementById('productname').value = '';
    document.getElementById('productprice').value = '';
    document.getElementById('productdesc').value = '';
}
window.onload = function () {
    const username = localStorage.getitem('username');
    if (username) {
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('app-section').style.display = 'block';
        document.getElementById('user-name').textContent = username;
    }
};